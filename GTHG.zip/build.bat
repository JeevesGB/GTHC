@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem ============================================================
rem  GT Hybrid Creator - build script
rem  Sources live in src\ ; everything generated lives in BUILD\
rem    BUILD\venv   build environment (kept between builds)
rem    BUILD\work   PyInstaller scratch files (recreated each build)
rem    BUILD\spec   generated .spec file (recreated each build)
rem    BUILD\dist   the finished app
rem
rem  Dependencies are only (re)installed when needed: first run,
rem  requirements.txt changed, or a package is missing. Otherwise
rem  the script goes straight to building.
rem
rem  Options:
rem    --onefile     single .exe (slower to start up)
rem    --reinstall   force dependency reinstall
rem    --nopause     don't wait for a keypress at the end
rem ============================================================
set "APP_NAME=GT Hybrid Creator"
set "SRC_DIR=%~dp0src"
set "BUILD_DIR=%~dp0BUILD"
set "VENV=%BUILD_DIR%\venv"
set "PY=%VENV%\Scripts\python.exe"
set "STAMP=%VENV%\requirements.installed.txt"
set "ONEFILE=0"
set "REINSTALL=0"
set "NOPAUSE=0"

for %%A in (%*) do (
    if /i "%%~A"=="--onefile"   set "ONEFILE=1"
    if /i "%%~A"=="--reinstall" set "REINSTALL=1"
    if /i "%%~A"=="--nopause"   set "NOPAUSE=1"
)

echo.
echo === %APP_NAME% build ===
echo.

if not exist "%SRC_DIR%\launcher.py" (
    echo [ERROR] %SRC_DIR%\launcher.py not found.
    goto :fail
)
if not exist "%~dp0requirements.txt" (
    echo [ERROR] requirements.txt not found.
    goto :fail
)

if not exist "%BUILD_DIR%" mkdir "%BUILD_DIR%"

rem --- 1. build environment ---
if not exist "%PY%" (
    where python >nul 2>&1
    if errorlevel 1 (
        echo [ERROR] Python was not found on PATH.
        echo         Install Python 3.10+ and tick "Add python.exe to PATH".
        goto :fail
    )
    echo [1/4] Creating virtual environment in BUILD\venv ...
    if exist "%VENV%" rmdir /s /q "%VENV%"
    python -m venv "%VENV%"
    if errorlevel 1 goto :fail
    set "REINSTALL=1"
) else (
    echo [1/4] Using existing virtual environment.
)

rem --- 2. dependencies (skipped when already installed) ---
set "NEED_DEPS=%REINSTALL%"
if not exist "%STAMP%" set "NEED_DEPS=1"
if "%NEED_DEPS%"=="0" (
    fc /b "%~dp0requirements.txt" "%STAMP%" >nul 2>&1
    if errorlevel 1 set "NEED_DEPS=1"
)
if "%NEED_DEPS%"=="0" (
    "%PY%" -c "import PyInstaller, PyQt6, matplotlib" >nul 2>&1
    if errorlevel 1 set "NEED_DEPS=1"
)

if "%NEED_DEPS%"=="1" (
    echo [2/4] Installing dependencies...
    "%PY%" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt" pyinstaller
    if errorlevel 1 goto :fail
    copy /y "%~dp0requirements.txt" "%STAMP%" >nul
) else (
    echo [2/4] Dependencies already installed - skipping.
)

rem --- 3. clean previous output (the venv is kept) ---
echo [3/4] Cleaning previous build...
if exist "%BUILD_DIR%\work" rmdir /s /q "%BUILD_DIR%\work"
if exist "%BUILD_DIR%\dist" rmdir /s /q "%BUILD_DIR%\dist"
if exist "%BUILD_DIR%\spec" rmdir /s /q "%BUILD_DIR%\spec"
mkdir "%BUILD_DIR%\spec"

rem --- 4. build ---
echo [4/4] Building with PyInstaller...
set "MODE=--onedir"
if "%ONEFILE%"=="1" set "MODE=--onefile"
set "ICON_ARG="
if exist "%SRC_DIR%\ico.ico" set ICON_ARG=--icon "%SRC_DIR%\ico.ico"
set "VER_ARG="
"%PY%" "%SRC_DIR%\make_version_info.py" "%BUILD_DIR%\spec\version_info.txt" "%APP_NAME%"
if errorlevel 1 goto :fail
set VER_ARG=--version-file "%BUILD_DIR%\spec\version_info.txt"
set "DATA_ARG="
if exist "%SRC_DIR%\ico.png" set DATA_ARG=--add-data "%SRC_DIR%\ico.png;."

"%PY%" -m PyInstaller --noconfirm --clean --windowed %MODE% ^
    --name "%APP_NAME%" ^
    --distpath "%BUILD_DIR%\dist" ^
    --workpath "%BUILD_DIR%\work" ^
    --specpath "%BUILD_DIR%\spec" ^
    --paths "%SRC_DIR%" ^
    --paths "%SRC_DIR%\gt3" ^
    --hidden-import hybrid_gui ^
    --hidden-import gt_engine ^
    --hidden-import gt4.window ^
    --hidden-import gt4.gt4_engine ^
    --hidden-import ui.design ^
    --hidden-import ui.folder_paths ^
    --hidden-import matplotlib.backends.backend_qtagg ^
    --exclude-module tkinter ^
    --exclude-module _tkinter ^
    --exclude-module pydoc ^
    --exclude-module doctest ^
    --exclude-module setuptools ^
    --exclude-module pkg_resources ^
    --exclude-module pytest ^
    --exclude-module IPython ^
    --exclude-module jupyter ^
    --exclude-module pandas ^
    --exclude-module scipy ^
    --exclude-module PyQt6.QtWebEngineCore ^
    --exclude-module PyQt6.QtWebEngineWidgets ^
    --exclude-module PyQt6.QtQml ^
    --exclude-module PyQt6.QtQuick ^
    --exclude-module PyQt6.QtQuickWidgets ^
    --exclude-module PyQt6.QtMultimedia ^
    --exclude-module PyQt6.QtMultimediaWidgets ^
    --exclude-module PyQt6.QtPdf ^
    --exclude-module PyQt6.QtPdfWidgets ^
    --exclude-module PyQt6.QtSql ^
    --exclude-module PyQt6.QtNetwork ^
    --exclude-module PyQt6.QtBluetooth ^
    --exclude-module PyQt6.QtSensors ^
    --exclude-module PyQt6.QtDesigner ^
    --exclude-module PyQt6.QtTest ^
    --exclude-module PyQt6.QtOpenGL ^
    --exclude-module PyQt6.QtOpenGLWidgets ^
    --exclude-module PyQt6.QtSvgWidgets ^
    --exclude-module PyQt6.QtPrintSupport ^
    --exclude-module PyQt6.Qt3DCore ^
    --exclude-module matplotlib.tests ^
    --exclude-module matplotlib.backends.backend_tkagg ^
    --exclude-module matplotlib.backends.backend_tkcairo ^
    --exclude-module matplotlib.backends.backend_gtk3 ^
    --exclude-module matplotlib.backends.backend_gtk3agg ^
    --exclude-module matplotlib.backends.backend_gtk4 ^
    --exclude-module matplotlib.backends.backend_gtk4agg ^
    --exclude-module matplotlib.backends.backend_wx ^
    --exclude-module matplotlib.backends.backend_wxagg ^
    --exclude-module matplotlib.backends.backend_webagg ^
    --exclude-module matplotlib.backends.backend_nbagg ^
    --exclude-module matplotlib.backends.backend_macosx ^
    --exclude-module matplotlib.backends.backend_cairo ^
    --exclude-module matplotlib.backends.backend_qt5agg ^
    --exclude-module matplotlib.backends.backend_qt5cairo ^
    --exclude-module numpy.tests ^
    --exclude-module numpy.f2py ^
    --exclude-module sqlite3 ^
    %ICON_ARG% ^
    %VER_ARG% ^
    %DATA_ARG% ^
    "%SRC_DIR%\launcher.py"
if errorlevel 1 goto :fail

rem --- 5. trim files PyInstaller bundles but the app never uses (onedir only) ---
set "INT=%BUILD_DIR%\dist\%APP_NAME%\_internal"
set "QT=%INT%\PyQt6\Qt6"
set "MPL=%INT%\matplotlib\mpl-data"
if not "%ONEFILE%"=="1" (
    echo Trimming unused files...

    rem Qt: translations, software OpenGL / DirectX fallbacks
    if exist "%QT%\translations" rmdir /s /q "%QT%\translations"
    for /r "%INT%" %%F in (opengl32sw.dll d3dcompiler_47.dll) do if exist "%%F" del /q "%%F"

    rem Qt: DLLs only needed by plugins removed below (PDF, networking). Keep Qt6Svg: matplotlib imports QtSvg
    for %%F in (Qt6Pdf.dll Qt6Network.dll) do if exist "%QT%\bin\%%F" del /q "%QT%\bin\%%F"

    rem Qt: plugins the app never loads (PNG support is built into QtGui)
    for %%D in (tls networkinformation iconengines generic) do if exist "%QT%\plugins\%%D" rmdir /s /q "%QT%\plugins\%%D"
    if exist "%QT%\plugins\imageformats" for %%F in ("%QT%\plugins\imageformats\*.dll") do (
        if /i not "%%~nxF"=="qico.dll" if /i not "%%~nxF"=="qjpeg.dll" if /i not "%%~nxF"=="qgif.dll" del /q "%%F"
    )

    rem matplotlib: sample data, toolbar icons, style sheets, and every font
    rem except DejaVu Sans + the LastResort fallback font matplotlib requires
    if exist "%MPL%\sample_data" rmdir /s /q "%MPL%\sample_data"
    if exist "%MPL%\images" rmdir /s /q "%MPL%\images"
    if exist "%MPL%\stylelib" rmdir /s /q "%MPL%\stylelib"
    if exist "%MPL%\fonts\pdfcorefonts" rmdir /s /q "%MPL%\fonts\pdfcorefonts"
    if exist "%MPL%\fonts\afm" rmdir /s /q "%MPL%\fonts\afm"
    if exist "%MPL%\fonts\ttf" for %%F in ("%MPL%\fonts\ttf\*.ttf") do (
        if /i not "%%~nxF"=="DejaVuSans.ttf" if /i not "%%~nxF"=="DejaVuSans-Bold.ttf" if /i not "%%~nxF"=="LastResortHE-Regular.ttf" del /q "%%F"
    )

    rem report final size and the 10 biggest files
    powershell -NoProfile -Command "$d='%BUILD_DIR%\dist\%APP_NAME%'; $f=Get-ChildItem $d -Recurse -File; Write-Host ('Total size: {0:N1} MB' -f (($f|Measure-Object Length -Sum).Sum/1MB)); $f|Sort-Object Length -Desc|Select-Object -First 12 @{n='MB';e={[math]::Round($_.Length/1MB,1)}},@{n='File';e={$_.FullName.Substring($d.Length)}}|Format-Table -AutoSize"
)

echo.
echo === Build complete ===
if "%ONEFILE%"=="1" (
    echo Output: BUILD\dist\%APP_NAME%.exe
) else (
    echo Output: BUILD\dist\%APP_NAME%\%APP_NAME%.exe
)
echo.
if not "%NOPAUSE%"=="1" pause
exit /b 0

:fail
echo.
echo === Build FAILED - see messages above ===
echo.
if not "%NOPAUSE%"=="1" pause
exit /b 1
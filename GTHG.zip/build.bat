@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem ============================================================
rem  GT Hybrid Creator - build script
rem  Sources live in src\ ; everything generated lives in BUILD\
rem    BUILD\venv   build environment (kept between builds)
rem    BUILD\work   PyInstaller scratch files (recreated each build)
rem    BUILD\spec   generated .spec file (recreated each build)
rem    BUILD\dist   the finished app
rem
rem  Dependencies are only (re)installed when needed: first run,
rem  requirements.txt changed, or a package is missing. Otherwise
rem  the script goes straight to building.
rem
rem  Options:
rem    --onefile     single .exe (slower to start up)
rem    --reinstall   force dependency reinstall
rem    --nopause     don't wait for a keypress at the end
rem ============================================================
set "APP_NAME=GT Hybrid Creator"
set "SRC_DIR=%~dp0src"
set "BUILD_DIR=%~dp0BUILD"
set "VENV=%BUILD_DIR%\venv"
set "PY=%VENV%\Scripts\python.exe"
set "STAMP=%VENV%\requirements.installed.txt"
set "ONEFILE=0"
set "REINSTALL=0"
set "NOPAUSE=0"

for %%A in (%*) do (
    if /i "%%~A"=="--onefile"   set "ONEFILE=1"
    if /i "%%~A"=="--reinstall" set "REINSTALL=1"
    if /i "%%~A"=="--nopause"   set "NOPAUSE=1"
)

echo.
echo === %APP_NAME% build ===
echo.

if not exist "%SRC_DIR%\launcher.py" (
    echo [ERROR] %SRC_DIR%\launcher.py not found.
    goto :fail
)
if not exist "%~dp0requirements.txt" (
    echo [ERROR] requirements.txt not found.
    goto :fail
)

if not exist "%BUILD_DIR%" mkdir "%BUILD_DIR%"

rem --- 1. build environment ---
if not exist "%PY%" (
    where python >nul 2>&1
    if errorlevel 1 (
        echo [ERROR] Python was not found on PATH.
        echo         Install Python 3.10+ and tick "Add python.exe to PATH".
        goto :fail
    )
    echo [1/4] Creating virtual environment in BUILD\venv ...
    if exist "%VENV%" rmdir /s /q "%VENV%"
    python -m venv "%VENV%"
    if errorlevel 1 goto :fail
    set "REINSTALL=1"
) else (
    echo [1/4] Using existing virtual environment.
)

rem --- 2. dependencies (skipped when already installed) ---
set "NEED_DEPS=%REINSTALL%"
if not exist "%STAMP%" set "NEED_DEPS=1"
if "%NEED_DEPS%"=="0" (
    fc /b "%~dp0requirements.txt" "%STAMP%" >nul 2>&1
    if errorlevel 1 set "NEED_DEPS=1"
)
if "%NEED_DEPS%"=="0" (
    "%PY%" -c "import PyInstaller, PyQt6, matplotlib" >nul 2>&1
    if errorlevel 1 set "NEED_DEPS=1"
)

if "%NEED_DEPS%"=="1" (
    echo [2/4] Installing dependencies...
    "%PY%" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt" pyinstaller
    if errorlevel 1 goto :fail
    copy /y "%~dp0requirements.txt" "%STAMP%" >nul
) else (
    echo [2/4] Dependencies already installed - skipping.
)

rem --- 3. clean previous output (the venv is kept) ---
echo [3/4] Cleaning previous build...
if exist "%BUILD_DIR%\work" rmdir /s /q "%BUILD_DIR%\work"
if exist "%BUILD_DIR%\dist" rmdir /s /q "%BUILD_DIR%\dist"
if exist "%BUILD_DIR%\spec" rmdir /s /q "%BUILD_DIR%\spec"
mkdir "%BUILD_DIR%\spec"

rem --- 4. build ---
echo [4/4] Building with PyInstaller...
set "MODE=--onedir"
if "%ONEFILE%"=="1" set "MODE=--onefile"
set "ICON_ARG="
if exist "%SRC_DIR%\icon.ico" set ICON_ARG=--icon "%SRC_DIR%\icon.ico"

"%PY%" -m PyInstaller --noconfirm --clean --windowed %MODE% ^
    --name "%APP_NAME%" ^
    --distpath "%BUILD_DIR%\dist" ^
    --workpath "%BUILD_DIR%\work" ^
    --specpath "%BUILD_DIR%\spec" ^
    --paths "%SRC_DIR%" ^
    --paths "%SRC_DIR%\gt3" ^
    --hidden-import hybrid_gui ^
    --hidden-import gt_engine ^
    --hidden-import gt4.window ^
    --hidden-import gt4.gt4_engine ^
    --hidden-import ui.design ^
    --hidden-import ui.folder_paths ^
    --hidden-import matplotlib.backends.backend_qtagg ^
    --exclude-module tkinter ^
    %ICON_ARG% ^
    "%SRC_DIR%\launcher.py"
if errorlevel 1 goto :fail

echo.
echo === Build complete ===
if "%ONEFILE%"=="1" (
    echo Output: BUILD\dist\%APP_NAME%.exe
) else (
    echo Output: BUILD\dist\%APP_NAME%\%APP_NAME%.exe
)
echo.
if not "%NOPAUSE%"=="1" pause
exit /b 0

:fail
echo.
echo === Build FAILED - see messages above ===
echo.
if not "%NOPAUSE%"=="1" pause
exit /b 1